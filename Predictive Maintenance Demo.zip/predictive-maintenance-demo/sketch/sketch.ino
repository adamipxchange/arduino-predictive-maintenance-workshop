#include <Arduino_RouterBridge.h>
#include <Arduino_Modulino.h>
#include <Arduino_LED_Matrix.h>

ModulinoMovement movement;
Arduino_LED_Matrix matrix;

const uint8_t FRAME_SIZE = 8 * 13;
uint8_t frameOn[FRAME_SIZE];

// 16 ms -> 62.5 Hz, the rate the Edge Impulse model was trained at
const long SAMPLE_INTERVAL_MS = 16;
unsigned long previousMillis = 0;

void setMatrixState(int state) {
  if (state) {
    matrix.draw(frameOn);
  } else {
    matrix.clear();
  }
}

void setup() {
  Bridge.begin();
  Monitor.begin(115200);

  matrix.begin();
  matrix.setGrayscaleBits(3);
  matrix.clear();
  for (uint8_t i = 0; i < FRAME_SIZE; i++) {
    frameOn[i] = 7;
  }

  Bridge.provide("set_matrix", setMatrixState);

  Modulino.begin(Wire1);
  while (!movement.begin()) {
    Monitor.println("Modulino Movement not found, retrying...");
    delay(1000);
  }
  Monitor.println("Modulino Movement ready");
}

void loop() {
  unsigned long currentMillis = millis();

  if (currentMillis - previousMillis >= SAMPLE_INTERVAL_MS) {
    previousMillis = currentMillis;

    if (movement.update() == 1) {
      // Acceleration in g; Python converts to m/s^2 for the model
      Bridge.notify("record_sensor_movement",
                    movement.getX(), movement.getY(), movement.getZ());
    }
  }
}
