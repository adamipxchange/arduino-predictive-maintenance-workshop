# UNO Q Modulino Edge Impulse Direct Uploader

This Arduino App Lab application captures accelerometer data from a Modulino
Movement and uploads it directly to an Edge Impulse project over the UNO Q's
internet connection. It does not use `edge-impulse-data-forwarder` or a USB
serial port.

## Hardware

- Arduino UNO Q
- Modulino Movement connected to the UNO Q Qwiic connector
- An internet connection configured on the UNO Q

## Use

1. Import this ZIP into Arduino App Lab and run the application.
2. Open the application interface shown by App Lab.
3. Confirm that **Modulino Movement connected** is displayed.
4. In Edge Impulse Studio, open **Dashboard → Keys**.
5. Paste the project's API key and development HMAC key into the app.
6. Choose a label, training or testing data, a sample duration, and an optional
   start delay (giving you time to get the board moving before sampling begins).
7. Select **Capture and upload**.
8. Open **Data acquisition** in Edge Impulse Studio to view the new sample.

The axes are named `accX`, `accY` and `accZ`; values are uploaded in `m/s2` at
62.5 Hz. Keys are kept in memory for the request and are not written to a file.

## Troubleshooting

- **Sensor not detected:** check the Qwiic cable, then stop and restart the app.
- **HTTP 401 or 403:** check that the API key belongs to the intended project.
- **Signature or HMAC error:** use the development HMAC key from the same Edge
  Impulse project as the API key.
- **Could not reach Edge Impulse:** confirm that the UNO Q itself has internet
  access, not only the computer running App Lab.
