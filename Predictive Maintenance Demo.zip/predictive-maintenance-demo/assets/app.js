'use strict';

const SAMPLE_RATE_HZ = 62.5;
const MAX_SAMPLES = 500; // ~8 s of history at 62.5 Hz
const MAX_EVENTS = 10;
const SLIDER_MAX = 20;
const MAX_SAMPLE_HISTORY = 10 * 60 * SAMPLE_RATE_HZ; // ~10 min for CSV export
const MAX_WINDOW_HISTORY = 2000;

const COLORS = {
  x: getCss('--series-x'),
  y: getCss('--series-y'),
  z: getCss('--series-z'),
  grid: getCss('--grid'),
  baseline: getCss('--baseline'),
  muted: getCss('--ink-muted'),
  ink: getCss('--ink-2'),
};

function getCss(name) {
  return getComputedStyle(document.documentElement).getPropertyValue(name).trim();
}

const samples = [];
const sampleHistory = []; // {t, x, y, z} for CSV export
const windowHistory = []; // scored windows for CSV export
let threshold = 1.0;
let lastInference = null;
let wasAnomalous = false;
let hasData = false;
let dirty = false;
let lastSampleAt = 0;

const canvas = document.getElementById('plot');
const ctx = canvas.getContext('2d');
const tooltip = document.getElementById('tooltip');
const noData = document.getElementById('no-data');
const slider = document.getElementById('threshold-slider');
const input = document.getElementById('threshold-input');

const ui = new WebUI();

ui.on_connect(() => {
  setPill('link-pill', 'pill-on', 'Board connected');
  ui.send_message('get_state');
});

ui.on_disconnect(() => {
  setPill('link-pill', 'pill-off', 'Board disconnected');
  setPill('stream-pill', 'pill-off', 'No sensor data');
});

ui.on_message('sample', s => {
  samples.push(s);
  if (samples.length > MAX_SAMPLES) samples.shift();
  sampleHistory.push({ t: new Date().toISOString(), x: s.x, y: s.y, z: s.z });
  if (sampleHistory.length > MAX_SAMPLE_HISTORY) sampleHistory.shift();
  lastSampleAt = performance.now();
  if (!hasData) {
    hasData = true;
    noData.hidden = true;
  }
  dirty = true;
});

ui.on_message('inference', handleInference);

ui.on_message('threshold', msg => {
  if (msg && typeof msg.value === 'number') applyThreshold(msg.value, false);
});

ui.on_message('paused', msg => {
  if (msg && typeof msg.value === 'boolean') applyPaused(msg.value);
});

ui.on_message('state', msg => {
  if (!msg) return;
  if (typeof msg.threshold === 'number') applyThreshold(msg.threshold, false);
  if (typeof msg.paused === 'boolean') applyPaused(msg.paused);
  if (msg.model) {
    if (msg.model.frequency) {
      document.getElementById('model-freq').textContent = `${msg.model.frequency} Hz`;
    }
    if (msg.model.window_seconds) {
      document.getElementById('model-window').textContent = `${msg.model.window_seconds} s`;
    }
  }
});

/* ---------------- status / inference ---------------- */

function handleInference(msg) {
  lastInference = msg;
  windowHistory.push(msg);
  if (windowHistory.length > MAX_WINDOW_HISTORY) windowHistory.shift();
  setMatrixPreview(msg.anomalous);
  const tile = document.getElementById('status-tile');
  const icon = document.getElementById('status-icon');
  const label = document.getElementById('status-label');
  const sub = document.getElementById('status-sub');
  const time = new Date(msg.timestamp);

  tile.classList.remove('status-idle', 'status-normal', 'status-anomaly');
  if (msg.anomalous) {
    tile.classList.add('status-anomaly');
    icon.textContent = '!';
    label.textContent = 'Anomaly detected';
    setPill('stream-pill', 'pill-alarm', 'Streaming · anomaly');
    // Edge-triggered: log only when entering the anomalous state, not for
    // every 2-second window that stays anomalous
    if (!wasAnomalous) addEvent(msg);
  } else {
    tile.classList.add('status-normal');
    icon.textContent = '✓';
    label.textContent = 'Normal operation';
    setPill('stream-pill', 'pill-on', 'Streaming · normal');
  }
  sub.textContent = `Last window scored at ${time.toLocaleTimeString()}`;

  document.getElementById('score-value').textContent = msg.score.toFixed(2);

  const fill = document.getElementById('score-bar-fill');
  // Threshold sits at the middle of the bar; full scale = 2x threshold
  const scale = Math.max(threshold * 2, 0.001);
  fill.style.width = `${Math.min(100, (msg.score / scale) * 100)}%`;
  fill.classList.toggle('over', msg.anomalous);

  const note = document.getElementById('matrix-note');
  note.classList.toggle('alarm', msg.anomalous);
  note.innerHTML = msg.anomalous
    ? 'LED matrix: <strong>on</strong> — anomalous vibration'
    : 'LED matrix: <strong>off</strong> — normal operation';

  wasAnomalous = msg.anomalous;
}

function addEvent(msg) {
  document.getElementById('events-empty').hidden = true;
  const list = document.getElementById('events-list');
  const item = document.createElement('li');
  item.className = 'event-item';
  const time = new Date(msg.timestamp);

  const img = document.createElement('img');
  img.src = renderSnapshot(samples);
  img.alt = `Accelerometer snapshot at ${time.toLocaleTimeString()}`;

  const meta = document.createElement('div');
  meta.className = 'event-meta';
  meta.innerHTML =
    `<div class="event-time">${time.toLocaleTimeString()} · ${time.toLocaleDateString()}</div>` +
    `<div class="event-detail">Score <span class="score">${msg.score.toFixed(2)}</span>` +
    ` · threshold ${msg.threshold.toFixed(1)}</div>`;

  item.appendChild(img);
  item.appendChild(meta);
  list.prepend(item);
  while (list.children.length > MAX_EVENTS) list.removeChild(list.lastChild);
}

// Render the current sample buffer to a small offscreen chart for the log
function renderSnapshot(data) {
  const w = 360, h = 128, pad = 6;
  const off = document.createElement('canvas');
  off.width = w;
  off.height = h;
  const octx = off.getContext('2d');

  octx.fillStyle = getCss('--page') || '#0d0d0d';
  octx.fillRect(0, 0, w, h);
  if (data.length < 2) return off.toDataURL('image/png');

  let min = Infinity, max = -Infinity;
  for (const s of data) {
    min = Math.min(min, s.x, s.y, s.z);
    max = Math.max(max, s.x, s.y, s.z);
  }
  const span = Math.max(max - min, 0.5);
  min -= span * 0.1;
  max += span * 0.1;

  const yOf = v => pad + (1 - (v - min) / (max - min)) * (h - 2 * pad);
  const xOf = i => pad + (i / (data.length - 1)) * (w - 2 * pad);

  for (const key of ['x', 'y', 'z']) {
    octx.strokeStyle = COLORS[key];
    octx.lineWidth = 2;
    octx.lineJoin = 'round';
    octx.beginPath();
    for (let i = 0; i < data.length; i++) {
      const px = xOf(i);
      const py = yOf(data[i][key]);
      if (i === 0) octx.moveTo(px, py);
      else octx.lineTo(px, py);
    }
    octx.stroke();
  }
  return off.toDataURL('image/png');
}

/* ---------------- LED matrix preview ---------------- */

const matrixPreview = document.getElementById('matrix-preview');
for (let i = 0; i < 8 * 13; i++) {
  const px = document.createElement('div');
  px.className = 'px';
  matrixPreview.appendChild(px);
}

function setMatrixPreview(on) {
  matrixPreview.classList.toggle('on', on);
}

/* ---------------- CSV export ---------------- */

function downloadCsv(filename, header, rows) {
  const csv = [header, ...rows].join('\n');
  const blob = new Blob([csv], { type: 'text/csv;charset=utf-8' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  a.click();
  URL.revokeObjectURL(url);
}

function stamp() {
  return new Date().toISOString().replace(/[:.]/g, '-').slice(0, 19);
}

document.getElementById('export-samples').addEventListener('click', () => {
  const rows = sampleHistory.map(s =>
    `${s.t},${s.x.toFixed(4)},${s.y.toFixed(4)},${s.z.toFixed(4)}`);
  downloadCsv(`pm-samples-${stamp()}.csv`, 'timestamp,accX_ms2,accY_ms2,accZ_ms2', rows);
});

document.getElementById('export-anomalies').addEventListener('click', () => {
  const rows = windowHistory.map(iw =>
    `${iw.timestamp},${iw.score},${iw.threshold},${iw.anomalous ? 1 : 0}`);
  downloadCsv(`pm-windows-${stamp()}.csv`, 'timestamp,anomaly_score,threshold,anomalous', rows);
});

/* ---------------- pause / clear log ---------------- */

let isPaused = false;
const pauseBtn = document.getElementById('pause-btn');

function applyPaused(value) {
  isPaused = value;
  pauseBtn.textContent = isPaused ? '▶ Resume' : '⏸ Pause';
  pauseBtn.classList.toggle('paused', isPaused);
  if (isPaused) {
    setPill('stream-pill', 'pill-off', 'Paused');
  }
}

pauseBtn.addEventListener('click', () => {
  ui.send_message('set_paused', !isPaused);
});

document.getElementById('clear-log').addEventListener('click', () => {
  document.getElementById('events-list').innerHTML = '';
  document.getElementById('events-empty').hidden = false;
});

function setPill(id, cls, text) {
  const pill = document.getElementById(id);
  pill.classList.remove('pill-on', 'pill-off', 'pill-alarm');
  pill.classList.add(cls);
  pill.innerHTML = `<span class="dot"></span>${text}`;
}

/* ---------------- threshold controls ---------------- */

let sendTimer = null;

function applyThreshold(value, send) {
  threshold = Math.max(0, value);
  slider.value = Math.min(SLIDER_MAX, threshold);
  if (document.activeElement !== input) input.value = threshold.toFixed(1);
  document.getElementById('threshold-value').textContent = threshold.toFixed(1);

  if (send) {
    clearTimeout(sendTimer);
    sendTimer = setTimeout(() => ui.send_message('set_threshold', threshold), 150);
  }
}

slider.addEventListener('input', () => applyThreshold(parseFloat(slider.value), true));
input.addEventListener('change', () => {
  const value = parseFloat(input.value);
  if (!isNaN(value)) applyThreshold(value, true);
  input.value = threshold.toFixed(1);
});

/* ---------------- chart ---------------- */

let hoverX = null;

canvas.addEventListener('mousemove', e => {
  const rect = canvas.getBoundingClientRect();
  hoverX = e.clientX - rect.left;
  dirty = true;
});
canvas.addEventListener('mouseleave', () => {
  hoverX = null;
  tooltip.hidden = true;
  dirty = true;
});

function niceStep(range) {
  const raw = range / 5;
  const pow = Math.pow(10, Math.floor(Math.log10(raw)));
  for (const m of [1, 2, 5, 10]) {
    if (raw <= m * pow) return m * pow;
  }
  return 10 * pow;
}

function draw() {
  requestAnimationFrame(draw);
  if (!dirty || !hasData) return;
  dirty = false;

  const dpr = window.devicePixelRatio || 1;
  const w = canvas.clientWidth;
  const h = canvas.clientHeight;
  if (canvas.width !== w * dpr || canvas.height !== h * dpr) {
    canvas.width = w * dpr;
    canvas.height = h * dpr;
  }
  ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  ctx.clearRect(0, 0, w, h);

  const padL = 44, padR = 10, padT = 10, padB = 22;
  const plotW = w - padL - padR;
  const plotH = h - padT - padB;
  if (plotW <= 0 || plotH <= 0 || samples.length < 2) return;

  // Autoscale with padding, symmetric-ish nice bounds
  let min = Infinity, max = -Infinity;
  for (const s of samples) {
    min = Math.min(min, s.x, s.y, s.z);
    max = Math.max(max, s.x, s.y, s.z);
  }
  const pad = Math.max((max - min) * 0.15, 1);
  min -= pad;
  max += pad;
  const step = niceStep(max - min);
  min = Math.floor(min / step) * step;
  max = Math.ceil(max / step) * step;

  const yOf = v => padT + (1 - (v - min) / (max - min)) * plotH;
  const xOf = i => padL + (i / (MAX_SAMPLES - 1)) * plotW;

  // Grid + labels
  ctx.strokeStyle = COLORS.grid;
  ctx.fillStyle = COLORS.muted;
  ctx.lineWidth = 1;
  ctx.font = '11px system-ui, sans-serif';
  ctx.textAlign = 'right';
  ctx.textBaseline = 'middle';
  for (let v = min; v <= max + step / 2; v += step) {
    const y = yOf(v);
    ctx.beginPath();
    ctx.moveTo(padL, y);
    ctx.lineTo(w - padR, y);
    ctx.stroke();
    ctx.fillText(v.toFixed(step < 1 ? 1 : 0), padL - 8, y);
  }

  // Time axis caption
  ctx.textAlign = 'center';
  ctx.textBaseline = 'alphabetic';
  const seconds = (samples.length / SAMPLE_RATE_HZ).toFixed(0);
  ctx.fillText(`last ${seconds} s`, padL + plotW / 2, h - 6);

  // Series
  const offset = MAX_SAMPLES - samples.length;
  for (const key of ['x', 'y', 'z']) {
    ctx.strokeStyle = COLORS[key];
    ctx.lineWidth = 2;
    ctx.lineJoin = 'round';
    ctx.beginPath();
    for (let i = 0; i < samples.length; i++) {
      const px = xOf(offset + i);
      const py = yOf(samples[i][key]);
      if (i === 0) ctx.moveTo(px, py);
      else ctx.lineTo(px, py);
    }
    ctx.stroke();
  }

  // Crosshair + tooltip
  if (hoverX !== null && hoverX >= padL && hoverX <= w - padR) {
    const idx = Math.round(((hoverX - padL) / plotW) * (MAX_SAMPLES - 1)) - offset;
    if (idx >= 0 && idx < samples.length) {
      const s = samples[idx];
      const px = xOf(offset + idx);
      ctx.strokeStyle = COLORS.baseline;
      ctx.lineWidth = 1;
      ctx.beginPath();
      ctx.moveTo(px, padT);
      ctx.lineTo(px, padT + plotH);
      ctx.stroke();

      tooltip.hidden = false;
      tooltip.innerHTML =
        `X <b>${s.x.toFixed(2)}</b>&nbsp; Y <b>${s.y.toFixed(2)}</b>&nbsp; Z <b>${s.z.toFixed(2)}</b> m/s²`;
      const left = Math.min(px + 12, w - tooltip.offsetWidth - 8);
      tooltip.style.left = `${Math.max(padL, left)}px`;
      tooltip.style.top = '12px';
    }
  } else {
    tooltip.hidden = true;
  }
}

// Fall back to "no sensor data" if the stream stalls
setInterval(() => {
  if (hasData && !isPaused && performance.now() - lastSampleAt > 3000) {
    setPill('stream-pill', 'pill-off', 'Sensor stream stalled');
  }
}, 1000);

applyThreshold(threshold, false);
requestAnimationFrame(draw);
