#include <Arduino_Modulino.h>
#include <Arduino_RouterBridge.h>

constexpr float G_TO_MS2 = 9.80665f;
constexpr unsigned long SAMPLE_INTERVAL_US = 16000UL;  // 62.5 Hz
constexpr int MAX_BATCH_SAMPLES = 16;

ModulinoMovement movement;
bool movementReady = false;

bool initialiseMovement() {
  if (movementReady) {
    return true;
  }

  movementReady = movement.begin();
  return movementReady;
}

String sensorStatus() {
  return initialiseMovement() ? "ready" : "not_found";
}

String captureBatch(int requestedSamples) {
  if (!initialiseMovement()) {
    return "ERROR:Modulino Movement not found";
  }

  const int sampleCount = constrain(requestedSamples, 1, MAX_BATCH_SAMPLES);
  String output;
  output.reserve(sampleCount * 40);

  unsigned long nextSampleUs = micros() + SAMPLE_INTERVAL_US;

  for (int i = 0; i < sampleCount; ++i) {
    while (static_cast<long>(micros() - nextSampleUs) < 0) {
      delayMicroseconds(100);
    }
    nextSampleUs += SAMPLE_INTERVAL_US;

    if (!movement.update()) {
      return "ERROR:Unable to read Modulino Movement";
    }

    output += String(movement.getX() * G_TO_MS2, 6);
    output += ',';
    output += String(movement.getY() * G_TO_MS2, 6);
    output += ',';
    output += String(movement.getZ() * G_TO_MS2, 6);
    output += '\n';
  }

  return output;
}

void setup() {
  Monitor.begin(115200);
  Modulino.begin(Wire1);
  Bridge.begin();

  Bridge.provide("sensor_status", sensorStatus);
  Bridge.provide("capture_batch", captureBatch);
}

void loop() {
  // Sensor acquisition is requested by the Linux-side App Lab process over RPC.
}
