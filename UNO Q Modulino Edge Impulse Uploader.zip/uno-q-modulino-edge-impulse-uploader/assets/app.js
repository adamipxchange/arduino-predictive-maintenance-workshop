const form = document.querySelector('#capture-form');
const captureButton = document.querySelector('#capture-button');
const checkButton = document.querySelector('#check-button');
const statusDot = document.querySelector('#status-dot');
const sensorStatus = document.querySelector('#sensor-status');
const sensorDetail = document.querySelector('#sensor-detail');
const resultBox = document.querySelector('#result');

function showResult(kind, message) {
  resultBox.className = `result ${kind}`;
  resultBox.textContent = message;
}

async function checkSensor() {
  checkButton.disabled = true;
  statusDot.className = 'status-dot checking';
  sensorStatus.textContent = 'Checking sensor…';
  sensorDetail.textContent = 'Contacting the STM32 over the UNO Q Bridge.';

  try {
    const response = await fetch('/api/sensor-status', { cache: 'no-store' });
    const data = await response.json();
    if (response.ok && data.ok) {
      statusDot.className = 'status-dot ready';
      sensorStatus.textContent = 'Modulino Movement connected';
      sensorDetail.textContent = 'Ready to capture accX, accY and accZ at 62.5 Hz.';
    } else {
      statusDot.className = 'status-dot error';
      sensorStatus.textContent = 'Modulino Movement not detected';
      sensorDetail.textContent = data.error || 'Check the Qwiic cable, then restart the app.';
    }
  } catch (error) {
    statusDot.className = 'status-dot error';
    sensorStatus.textContent = 'Unable to check the sensor';
    sensorDetail.textContent = error.message;
  } finally {
    checkButton.disabled = false;
  }
}

form.addEventListener('submit', async (event) => {
  event.preventDefault();
  captureButton.disabled = true;
  checkButton.disabled = true;

  const duration = Number(document.querySelector('#duration').value);
  const delay = Number(document.querySelector('#delay').value);
  const delayNote = delay > 0 ? `Waiting ${delay} s, then c` : 'C';
  showResult(
    'running',
    `${delayNote}apturing approximately ${duration * 62.5} accelerometer readings, then uploading to Edge Impulse…`,
  );

  const config = {
    apiKey: document.querySelector('#api-key').value,
    hmacKey: document.querySelector('#hmac-key').value,
    label: document.querySelector('#label').value,
    category: document.querySelector('#category').value,
    duration,
    delay,
    deviceName: document.querySelector('#device-name').value,
  };

  try {
    const response = await fetch('/api/capture', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(config),
    });
    const data = await response.json();

    if (!response.ok || !data.ok) {
      const detail = data.detail ? ` ${data.detail}` : '';
      throw new Error(`${data.error || 'Capture failed.'}${detail}`);
    }

    showResult(
      'success',
      `Uploaded ${data.samples} readings (${data.duration.toFixed(2)} seconds) as “${data.label}” to ${data.category} data.`,
    );
  } catch (error) {
    showResult('error', error.message);
  } finally {
    captureButton.disabled = false;
    checkButton.disabled = false;
  }
});

checkButton.addEventListener('click', checkSensor);
checkSensor();
