import hashlib
import hmac
import json
import re
import threading
import time
import urllib.error
import urllib.request

from arduino.app_bricks.web_ui import WebUI
from arduino.app_utils import App, Bridge, Logger
from fastapi import Body
from fastapi.responses import JSONResponse


SAMPLE_FREQUENCY_HZ = 62.5
SAMPLE_INTERVAL_MS = 1000.0 / SAMPLE_FREQUENCY_HZ
BATCH_SIZE = 16
EMPTY_SIGNATURE = "0" * 64
INGESTION_BASE_URL = "https://ingestion.edgeimpulse.com"

logger = Logger("EdgeImpulseDirectUploader")
ui = WebUI()
capture_lock = threading.Lock()


def response(payload, status_code=200):
    return JSONResponse(content=payload, status_code=status_code)


def clean_text(value, field_name, max_length=80):
    text = str(value or "").strip()
    if not text:
        raise ValueError(f"{field_name} is required.")
    if len(text) > max_length:
        raise ValueError(f"{field_name} must be {max_length} characters or fewer.")
    return text


def parse_batch(raw_batch):
    if not isinstance(raw_batch, str):
        raise RuntimeError("The sensor returned an unexpected response.")
    if raw_batch.startswith("ERROR:"):
        raise RuntimeError(raw_batch.removeprefix("ERROR:"))

    values = []
    for line in raw_batch.splitlines():
        if not line.strip():
            continue
        parts = line.split(",")
        if len(parts) != 3:
            raise RuntimeError("The sensor returned a malformed sample.")
        values.append([float(parts[0]), float(parts[1]), float(parts[2])])
    return values


def build_signed_payload(values, device_name, hmac_key):
    envelope = {
        "protected": {
            "ver": "v1",
            "alg": "HS256",
            "iat": int(time.time()),
        },
        "signature": EMPTY_SIGNATURE,
        "payload": {
            "device_name": device_name,
            "device_type": "ARDUINO_UNO_Q_MODULINO_MOVEMENT",
            "interval_ms": SAMPLE_INTERVAL_MS,
            "sensors": [
                {"name": "accX", "units": "m/s2"},
                {"name": "accY", "units": "m/s2"},
                {"name": "accZ", "units": "m/s2"},
            ],
            "values": values,
        },
    }

    unsigned = json.dumps(envelope, separators=(",", ":"), ensure_ascii=False)
    envelope["signature"] = hmac.new(
        hmac_key.encode("utf-8"),
        unsigned.encode("utf-8"),
        hashlib.sha256,
    ).hexdigest()
    return json.dumps(envelope, separators=(",", ":"), ensure_ascii=False).encode("utf-8")


def upload_sample(encoded_payload, api_key, label, category):
    timestamp = time.strftime("%Y%m%d-%H%M%S", time.gmtime())
    safe_label = re.sub(r"[^A-Za-z0-9_.-]+", "-", label).strip("-.") or "sample"
    url = f"{INGESTION_BASE_URL}/api/{category}/data"
    request = urllib.request.Request(
        url,
        data=encoded_payload,
        method="POST",
        headers={
            "Content-Type": "application/json",
            "x-api-key": api_key,
            "x-file-name": f"{safe_label}-{timestamp}",
            "x-label": label,
        },
    )

    with urllib.request.urlopen(request, timeout=45) as result:
        body = result.read().decode("utf-8", errors="replace")
        return result.status, body


def get_sensor_status():
    try:
        status = Bridge.call("sensor_status")
        return response({"ok": status == "ready", "status": status})
    except Exception as exc:
        logger.error(f"Sensor status check failed: {exc}")
        return response({"ok": False, "error": str(exc)}, 500)


def capture_and_upload(config: dict = Body(...)):
    if not capture_lock.acquire(blocking=False):
        return response({"ok": False, "error": "A capture is already running."}, 409)

    try:
        api_key = clean_text(config.get("apiKey"), "Edge Impulse API key", 256)
        hmac_key = clean_text(config.get("hmacKey"), "Edge Impulse HMAC key", 256)
        label = clean_text(config.get("label"), "Label")
        device_name = clean_text(
            config.get("deviceName", "uno-q-modulino-movement"),
            "Device name",
        )

        category = str(config.get("category", "training")).strip().lower()
        if category not in {"training", "testing"}:
            raise ValueError("Category must be training or testing.")

        try:
            duration_seconds = float(config.get("duration", 10))
        except (TypeError, ValueError) as exc:
            raise ValueError("Duration must be a number.") from exc
        if not 1 <= duration_seconds <= 60:
            raise ValueError("Duration must be between 1 and 60 seconds.")

        try:
            delay_seconds = float(config.get("delay", 2))
        except (TypeError, ValueError) as exc:
            raise ValueError("Start delay must be a number.") from exc
        if not 0 <= delay_seconds <= 10:
            raise ValueError("Start delay must be between 0 and 10 seconds.")

        status = Bridge.call("sensor_status")
        if status != "ready":
            raise RuntimeError(
                "Modulino Movement was not detected. Check the Qwiic cable and restart the app."
            )

        if delay_seconds > 0:
            logger.info(f"Waiting {delay_seconds:g} s before sampling…")
            time.sleep(delay_seconds)

        target_samples = max(1, round(duration_seconds * SAMPLE_FREQUENCY_HZ))
        values = []

        while len(values) < target_samples:
            requested = min(BATCH_SIZE, target_samples - len(values))
            batch = parse_batch(Bridge.call("capture_batch", requested))
            if len(batch) != requested:
                raise RuntimeError(
                    f"Expected {requested} readings but received {len(batch)}."
                )
            values.extend(batch)

        encoded = build_signed_payload(values, device_name, hmac_key)
        status_code, body = upload_sample(encoded, api_key, label, category)

        logger.info(
            f"Uploaded {len(values)} samples as '{label}' to Edge Impulse {category} data."
        )
        return response(
            {
                "ok": True,
                "message": "Sample uploaded to Edge Impulse.",
                "samples": len(values),
                "duration": len(values) / SAMPLE_FREQUENCY_HZ,
                "category": category,
                "label": label,
                "edgeImpulseStatus": status_code,
                "edgeImpulseResponse": body[:500],
            }
        )
    except urllib.error.HTTPError as exc:
        detail = exc.read().decode("utf-8", errors="replace")
        logger.error(f"Edge Impulse rejected the upload ({exc.code}): {detail}")
        return response(
            {
                "ok": False,
                "error": f"Edge Impulse rejected the upload (HTTP {exc.code}).",
                "detail": detail[:500],
            },
            502,
        )
    except urllib.error.URLError as exc:
        logger.error(f"Could not reach Edge Impulse: {exc}")
        return response(
            {
                "ok": False,
                "error": "Could not reach Edge Impulse. Check the UNO Q internet connection.",
                "detail": str(exc.reason),
            },
            502,
        )
    except (ValueError, RuntimeError) as exc:
        logger.error(str(exc))
        return response({"ok": False, "error": str(exc)}, 400)
    except Exception as exc:
        logger.exception(f"Capture failed: {exc}")
        return response({"ok": False, "error": f"Capture failed: {exc}"}, 500)
    finally:
        capture_lock.release()


ui.expose_api(method="GET", path="/api/sensor-status", function=get_sensor_status)
ui.expose_api(method="POST", path="/api/capture", function=capture_and_upload)

App.run()
