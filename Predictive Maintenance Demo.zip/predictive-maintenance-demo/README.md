# Predictive Maintenance Demo

Live vibration anomaly detection on the Arduino UNO Q with a Modulino Movement
sensor and an Edge Impulse anomaly model, with an industrial web dashboard and
the LED matrix as a physical alarm.

## How it works

- The sketch samples the Modulino Movement accelerometer every 16 ms (62.5 Hz,
  the rate the model was trained at) and streams X/Y/Z values to Python over
  the Router Bridge.
- Python converts g to m/s² (the unit of the training data), feeds the
  `vibration_anomaly_detection` Brick, and receives an anomaly score for each
  2-second window.
- Each window's score is compared against the user-set threshold: at or above
  it the LED matrix turns fully on, below it the matrix is fully off.
- The web dashboard (port 7000) shows the live accelerometer plot, the machine
  status, the anomaly score per window, a threshold slider + numeric input, and
  a log of recent anomalies.

## Using your own Edge Impulse model

The app currently references the built-in `fan-anomaly-detection` model as a
placeholder. To use the model trained from the "UNO Q Modulino Edge Impulse
Uploader" data:

1. In App Lab, import your Edge Impulse project's model (Models section →
   import from Edge Impulse). It will appear with an id like `ei-model-<id>-1`.
2. In `app.yaml`, replace `fan-anomaly-detection` with that model id.
3. Restart the app.

## Hardware

- Arduino UNO Q
- Modulino Movement connected via the Qwiic connector

## Notes

- The anomaly score is a raw distance from the model's learned "normal", not a
  0–1 confidence — scores above 1 are common. Tune the threshold with the
  slider while watching the live scores.
- If no data appears, check the Qwiic cable and restart the app (the sketch
  retries the sensor every second and logs to the Serial Monitor).
