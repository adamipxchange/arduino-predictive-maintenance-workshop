import threading
from datetime import datetime

from arduino.app_utils import App, Bridge, Logger
from arduino.app_bricks.web_ui import WebUI
from arduino.app_bricks.vibration_anomaly_detection import VibrationAnomalyDetection

G_TO_MS2 = 9.80665
DEFAULT_THRESHOLD = 1.0

logger = Logger("predictive-maintenance")

vibration = VibrationAnomalyDetection(anomaly_detection_threshold=0.0)

# The brick only invokes its callback when score >= its internal threshold, so
# drive that as low as it will accept: the callback then fires for every
# completed window and the user-facing threshold is applied in this file.
for candidate in (-1e9, 0.0):
    try:
        vibration.anomaly_detection_threshold = candidate
        break
    except ValueError:
        continue

state_lock = threading.Lock()
user_threshold = DEFAULT_THRESHOLD
last_score = None
matrix_on = None
paused = False

ui = WebUI()


def set_matrix(anomalous: bool):
    global matrix_on
    if matrix_on == anomalous:
        return
    matrix_on = anomalous
    try:
        Bridge.notify("set_matrix", 1 if anomalous else 0)
        logger.info(f"LED matrix -> {'ON (anomaly)' if anomalous else 'OFF (normal)'}")
    except Exception as exc:
        logger.warning(f"Could not update LED matrix: {exc}")


def on_window_scored(anomaly_score: float, classification: dict = None):
    global last_score
    with state_lock:
        last_score = anomaly_score
        threshold = user_threshold
    anomalous = anomaly_score >= threshold
    set_matrix(anomalous)
    ui.send_message("inference", {
        "score": anomaly_score,
        "threshold": threshold,
        "anomalous": anomalous,
        "timestamp": datetime.now().isoformat(),
    })


vibration.on_anomaly(on_window_scored)


def record_sensor_movement(x: float, y: float, z: float):
    if paused:
        return

    # The sketch sends g; the model was trained on m/s^2 (Edge Impulse uploads)
    x_ms2 = x * G_TO_MS2
    y_ms2 = y * G_TO_MS2
    z_ms2 = z * G_TO_MS2

    ui.send_message("sample", {"x": x_ms2, "y": y_ms2, "z": z_ms2})
    vibration.accumulate_samples((x_ms2, y_ms2, z_ms2))


Bridge.provide("record_sensor_movement", record_sensor_movement)


def on_set_threshold(value):
    global user_threshold
    try:
        threshold = max(0.0, float(value))
    except (TypeError, ValueError):
        logger.warning(f"Ignoring invalid threshold {value!r}")
        return

    with state_lock:
        user_threshold = threshold
        score = last_score
    logger.info(f"Anomaly threshold set to {threshold}")
    ui.send_message("threshold", {"value": threshold})

    # Re-evaluate the LED matrix against the last window immediately
    if score is not None:
        set_matrix(score >= threshold)


ui.on_message("set_threshold", lambda sid, value: on_set_threshold(value))


def on_set_paused(value):
    global paused
    paused = bool(value)
    logger.info(f"Inference {'paused' if paused else 'resumed'}")
    ui.send_message("paused", {"value": paused})


ui.on_message("set_paused", lambda sid, value: on_set_paused(value))


def on_get_state(sid, data=None):
    with state_lock:
        payload = {"threshold": user_threshold, "score": last_score, "paused": paused}

    try:
        info = vibration.get_model_info()
        if info:
            frequency = getattr(info, "frequency", None)
            features = getattr(info, "input_features_count", None)
            model = {"frequency": frequency}
            if frequency and features:
                model["window_seconds"] = round(features / 3 / frequency, 2)
            payload["model"] = model
    except Exception as exc:
        logger.warning(f"Could not read model info: {exc}")

    ui.send_message("state", payload)


ui.on_message("get_state", on_get_state)

App.run()
